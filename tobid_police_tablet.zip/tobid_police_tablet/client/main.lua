-- Police Tablet Client Side
-- Version: 1.0.1 (Auto-open Bug Fix)

-- Framework Detection
local QBCore = nil
local ESX = nil

if Config.FrameWork == "qb" then
    QBCore = exports['qb-core']:GetCoreObject()
elseif Config.FrameWork == "esx" then
    ESX = exports["es_extended"]:getSharedObject()
end

local isOnDuty = false
local tabletOpen = false
local resourceStarted = false  -- FIX: Verhindert Auto-open beim Script-Start

-- Framework Helper Functions
local function GetPlayerData()
    if Config.FrameWork == "qb" and QBCore and QBCore.Functions then
        return QBCore.Functions.GetPlayerData()
    elseif Config.FrameWork == "esx" and ESX then
        return ESX.GetPlayerData()
    end
    return nil
end

local function GetPlayerName(playerData)
    if Config.FrameWork == "qb" then
        if playerData.charinfo and playerData.charinfo.firstname and playerData.charinfo.lastname then
            return playerData.charinfo.firstname .. ' ' .. playerData.charinfo.lastname
        else
            return 'Unknown Officer'
        end
    elseif Config.FrameWork == "esx" then
        if playerData.firstname and playerData.lastname then
            return playerData.firstname .. ' ' .. playerData.lastname
        else
            return 'Unknown Officer'
        end
    end
    return 'Unknown Officer'
end

local function GetPlayerJob(playerData)
    if Config.FrameWork == "qb" then
        return playerData.job
    elseif Config.FrameWork == "esx" then
        return playerData.job
    end
    return {name = 'unknown', label = 'Unknown'}
end

local function NotifyPlayer(message, type)
    if Config.FrameWork == "qb" and QBCore then
        QBCore:Notify(message, type)
    elseif Config.FrameWork == "esx" and ESX then
        ESX.ShowNotification(message, type)
    else
        print(message)
    end
end

-- FIX: NUI beim Start sofort schließen damit es nicht offen bleibt
AddEventHandler('onClientResourceStart', function(resourceName)
    if GetCurrentResourceName() ~= resourceName then return end
    -- Stelle sicher dass NUI beim Start geschlossen ist
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'closeTablet' })
    tabletOpen = false

    -- Warte kurz und erlaube dann erst das Öffnen per Taste
    CreateThread(function()
        Wait(2000)
        resourceStarted = true
        print('[Police Tablet] Bereit - Tablet kann jetzt geöffnet werden (F2)')
    end)
end)

-- Register NUI Callback
RegisterNUICallback('closeTablet', function(data, cb)
    SetNuiFocus(false, false)
    tabletOpen = false
    cb('ok')
end)

-- Open Tablet (Manual override) - Only register key if configured
if Config.tabletOpenKey and Config.tabletOpenKey ~= "" then
    RegisterKeyMapping('opentablet', 'Open Police Tablet', 'keyboard', Config.tabletOpenKey)
    print('[Police Tablet] F2-Taste aktiviert für Tablet-Öffnung')
else
    print('[Police Tablet] F2-Taste deaktiviert - nur Command verfügbar')
end

RegisterCommand('opentablet', function()
    -- FIX: Blockiere öffnen bis Resource vollständig geladen ist
    if not resourceStarted then
        print('[Police Tablet] Noch nicht bereit...')
        return
    end

    local Player = GetPlayerData()
    if not Player then return end

    local PlayerJob = GetPlayerJob(Player)

    if PlayerJob.name == 'police' then
        if not tabletOpen then
            SetNuiFocus(true, true)
            SendNUIMessage({
                action = 'openTablet',
                playerData = {
                    name = GetPlayerName(Player),
                    job = PlayerJob.label,
                    callsign = (Config.FrameWork == "qb" and Player.metadata and Player.metadata.callsign) or 'NONE'
                }
            })
            tabletOpen = true
        else
            SetNuiFocus(false, false)
            SendNUIMessage({ action = 'closeTablet' })
            tabletOpen = false
        end
    else
        NotifyPlayer('Du bist kein Polizeibeamter!', 'error')
    end
end, false)

-- Service Status Update
RegisterNetEvent('police-tablet:client:UpdateServiceStatus')
AddEventHandler('police-tablet:client:UpdateServiceStatus', function(status)
    isOnDuty = status
    SendNUIMessage({
        action = 'updateServiceStatus',
        status = status
    })
end)

-- Receive Player Data
RegisterNetEvent('police-tablet:client:ReceivePlayerData')
AddEventHandler('police-tablet:client:ReceivePlayerData', function(data)
    SendNUIMessage({
        action = 'updatePlayerData',
        data = data
    })
end)

-- Receive Records
RegisterNetEvent('police-tablet:client:ReceiveRecords')
AddEventHandler('police-tablet:client:ReceiveRecords', function(records)
    SendNUIMessage({
        action = 'updateRecords',
        records = records
    })
end)

-- Receive Vehicle Data
RegisterNetEvent('police-tablet:client:ReceiveVehicleData')
AddEventHandler('police-tablet:client:ReceiveVehicleData', function(vehicles)
    SendNUIMessage({
        action = 'updateVehicleData',
        vehicles = vehicles
    })
end)

-- Receive Weapon Data
RegisterNetEvent('police-tablet:client:ReceiveWeaponData')
AddEventHandler('police-tablet:client:ReceiveWeaponData', function(weapons)
    SendNUIMessage({
        action = 'updateWeaponData',
        weapons = weapons
    })
end)

-- Legacy Events für Kompatibilität
RegisterNUICallback("close", function(data, cb)
    SetNuiFocus(false, false)
    tabletOpen = false
    cb('ok')
end)

RegisterNUICallback("escape", function(data, cb)
    SetNuiFocus(false, false)
    tabletOpen = false
    cb('ok')
end)

RegisterNUICallback("toggleDuty", function(data, cb)
    isOnDuty = not isOnDuty
    TriggerServerEvent("tablet:updateDuty", isOnDuty)
    cb('ok')
end)

RegisterNetEvent("tablet:dispatchAlert")
AddEventHandler("tablet:dispatchAlert", function(data)
    if isOnDuty then
        print("Dispatch: " .. data.message)
        SetNewWaypoint(data.coords.x, data.coords.y)
    end
end)

RegisterNetEvent("tablet:startJail")
AddEventHandler("tablet:startJail", function(coords, time)
    SetEntityCoords(PlayerPedId(), coords.x, coords.y, coords.z, false, false, false, true)
    local remaining = time
    CreateThread(function()
        while remaining > 0 do
            Wait(1000)
            remaining = remaining - 1
        end
        print("Haft beendet")
    end)
end)

function SearchWeaponsByName(name)
    local split = {}
    for word in string.gmatch(name, "[^%s]+") do
        table.insert(split, word)
    end
    TriggerServerEvent("tablet:getWeaponsByName", split[1], split[2])
end

RegisterNetEvent("tablet:returnWeaponsByName")
AddEventHandler("tablet:returnWeaponsByName", function(data)
    if data then
        print("Waffen von " .. data.name .. ":")
        for k, v in pairs(data.weapons) do
            print("  - " .. v.name .. " | Lizenz: " .. tostring(v.license))
        end
    else
        print("Keine Waffen gefunden")
    end
end)

function SearchPlate(plate)
    TriggerServerEvent("tablet:getVehicleByPlate", plate)
end

RegisterNetEvent("tablet:returnVehicleInfo")
AddEventHandler("tablet:returnVehicleInfo", function(data)
    if data then
        print("Fahrzeug: " .. data.model .. " | Besitzer: " .. data.owner .. " | Status: " .. data.status)
    else
        print("Kein Fahrzeug gefunden")
    end
end)

function GetRecordsByName(name)
    local split = {}
    for word in string.gmatch(name, "[^%s]+") do
        table.insert(split, word)
    end
    TriggerServerEvent("tablet:getRecords", split[1], split[2])
end

RegisterNetEvent("tablet:returnRecords")
AddEventHandler("tablet:returnRecords", function(records)
    local output = ""
    if records and #records > 0 then
        for k, v in pairs(records) do
            output = output .. string.format("[%s] %s - %s (Beamter: %s)\n", v.date, v.title, v.description, v.officer)
        end
    else
        output = "Keine Akteneinträge gefunden."
    end
    print(output)
end)

RegisterNUICallback("searchWeapons", function(data, cb)
    TriggerServerEvent("tablet:searchWeapons", data.player)
    cb("ok")
end)

RegisterNUICallback("searchPlate", function(data, cb)
    TriggerServerEvent("tablet:searchPlate", data.plate)
    cb("ok")
end)

RegisterNUICallback("addRecord", function(data, cb)
    TriggerServerEvent("tablet:addRecord", data.name, data.title, data.description, data.officer)
    cb("ok")
end)

RegisterNetEvent("tablet:showWeapons")
AddEventHandler("tablet:showWeapons", function(weapons)
    SendNUIMessage({
        type = "weapons",
        data = weapons
    })
end)

-- Export Functions
exports('GetRecordsByName', function(name)
    TriggerServerEvent('police-tablet:server:GetRecordsByName', name)
end)

exports('AddRecord', function(playerName, title, description, officer)
    TriggerServerEvent('police-tablet:server:AddRecord', playerName, title, description, officer)
end)

exports('SearchPlate', function(plate)
    TriggerServerEvent('police-tablet:server:SearchPlate', plate)
end)

exports('SearchWeapons', function(playerName)
    TriggerServerEvent('police-tablet:server:SearchWeapons', playerName)
end)

exports('startService', function()
    TriggerServerEvent('police-tablet:server:StartService')
end)

exports('endService', function()
    TriggerServerEvent('police-tablet:server:EndService')
end)

print('Police Tablet Client Loaded - Version 1.0.1')
