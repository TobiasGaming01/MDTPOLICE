// =============================================
// Police Tablet - app.js
// Version: 1.0.2
// =============================================

let tabletVisible = false;

// =============================================
// NUI MESSAGE HANDLER
// =============================================
window.addEventListener("message", function(event) {

    // --- Tablet ÖFFNEN ---
    if (event.data.action === "openTablet") {
        // FIX: body.tablet-open statt display toggle - funktioniert in FiveM NUI
        document.body.classList.add('tablet-open');
        tabletVisible = true;

        if (event.data.playerData) {
            const nameEl = document.getElementById('officer-name');
            if (nameEl) nameEl.textContent = event.data.playerData.name || 'Unknown';
        }
    }

    // --- Tablet SCHLIESSEN ---
    if (event.data.action === "closeTablet") {
        document.body.classList.remove('tablet-open');
        tabletVisible = false;
    }

    // --- Dienststatus Update ---
    if (event.data.action === "updateServiceStatus") {
        const statusEl = document.querySelector('#dienst-status span');
        if (statusEl) {
            statusEl.textContent = event.data.status ? 'Online' : 'Offline';
            statusEl.className   = event.data.status ? 'status-online' : 'status-offline';
        }
    }

    // --- Waffen ---
    if (event.data.type === "weapons" || event.data.action === "updateWeaponData") {
        const weapons = event.data.data || event.data.weapons;
        const output  = document.getElementById("waffen-output");
        if (output && weapons) {
            output.innerHTML = weapons.map(w => `<p>🔫 ${w.weapon || w.name}</p>`).join('');
        }
    }

    // --- Fahrzeuge ---
    if (event.data.action === "updateVehicleData") {
        const output = document.getElementById("fahrzeug-output");
        if (output && event.data.vehicles) {
            const v = event.data.vehicles;
            if (Array.isArray(v)) {
                output.innerHTML = v.map(x => `<p>🚗 ${x.model} | ${x.plate} | ${x.owner}</p>`).join('');
            } else {
                output.innerHTML = `<p>🚗 ${v.model || ''} | ${v.plate || ''} | Besitzer: ${v.owner || ''}</p>`;
            }
        }
    }

    // --- Akten ---
    if (event.data.action === "updateRecords") {
        const output = document.getElementById("record-output");
        if (output) {
            if (!event.data.records || event.data.records.length === 0) {
                output.innerHTML = "<p>Keine Akteneinträge gefunden.</p>";
                return;
            }
            output.innerHTML = "<ul>" + event.data.records.map(r =>
                `<li>[${r.date}] <b>${r.title}</b> — ${r.description} <i>(${r.officer})</i></li>`
            ).join('') + "</ul>";
        }
    }

    // --- Spielerdaten ---
    if (event.data.action === "updatePlayerData") {
        const nameEl = document.getElementById('officer-name');
        if (nameEl && event.data.data) nameEl.textContent = event.data.data.name || 'Unknown';
    }
});

// =============================================
// ESC zum Schließen
// =============================================
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && tabletVisible) closeTablet();
});

// =============================================
// NAVIGATION — nutzt data-tab Attribut (zuverlässiger als Text-Matching)
// =============================================
document.addEventListener('DOMContentLoaded', function() {

    // Alle Tab-Inhalte verstecken außer Dashboard
    document.querySelectorAll('.tab-content').forEach(content => {
        if (content.id !== 'dashboard-content') {
            content.style.display = 'none';
        }
    });

    // Nav Links mit data-tab
    document.querySelectorAll('.nav-link[data-tab]').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            // Aktiv-Klasse umschalten
            document.querySelectorAll('.nav-link').forEach(n => n.classList.remove('active'));
            this.classList.add('active');
            // Tabs verstecken
            document.querySelectorAll('.tab-content').forEach(c => c.style.display = 'none');
            // Gewünschten Tab anzeigen
            const target = document.getElementById(this.dataset.tab);
            if (target) target.style.display = 'block';
        });
    });

    // Einstellungen-Link (profile-link mit data-tab)
    document.querySelectorAll('.profile-link[data-tab]').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            document.querySelectorAll('.nav-link').forEach(n => n.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(c => c.style.display = 'none');
            const target = document.getElementById(this.dataset.tab);
            if (target) target.style.display = 'block';
        });
    });

    // Hintergrundbild Upload
    const bgUpload = document.getElementById("bg-upload");
    if (bgUpload) {
        bgUpload.addEventListener("change", function(event) {
            const file = event.target.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = e => {
                const tablet = document.getElementById("tablet");
                if (tablet) tablet.style.backgroundImage = `url(${e.target.result})`;
            };
            reader.readAsDataURL(file);
        });
    }

    // Sprache
    const languageSelect = document.getElementById("language-select");
    if (languageSelect) {
        languageSelect.addEventListener("change", function() {
            fetch(`https://${GetParentResourceName()}/setLanguage`, {
                method: "POST",
                body: JSON.stringify({ language: this.value })
            });
        });
    }

    // Theme
    const themeSelect = document.getElementById("theme-select");
    if (themeSelect) {
        themeSelect.addEventListener("change", function() {
            const tablet = document.getElementById("tablet");
            if (tablet) {
                this.value === "light" ? tablet.classList.add("light") : tablet.classList.remove("light");
            }
            fetch(`https://${GetParentResourceName()}/setTheme`, {
                method: "POST",
                body: JSON.stringify({ theme: this.value })
            });
        });
    }

    // Dispatch Toggle
    const dispatchToggle = document.getElementById("dispatch-toggle");
    if (dispatchToggle) {
        dispatchToggle.addEventListener("change", function() {
            fetch(`https://${GetParentResourceName()}/setDispatch`, {
                method: "POST",
                body: JSON.stringify({ dispatch: this.checked })
            });
        });
    }

    // Fine Item Click
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('fine-item')) {
            const a = document.getElementById('fine-amount');
            const p = document.getElementById('fine-points');
            const pr = document.getElementById('fine-prison');
            if (a) a.value  = e.target.dataset.amount  || '';
            if (p) p.value  = e.target.dataset.points  || '';
            if (pr) pr.value = e.target.dataset.prison || '';
        }
    });
});

// =============================================
// TABLET SCHLIESSEN
// =============================================
function closeTablet() {
    fetch(`https://${GetParentResourceName()}/closeTablet`, {
        method: "POST",
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
    });
    document.body.classList.remove('tablet-open');
    tabletVisible = false;
}

// =============================================
// BENACHRICHTIGUNG
// =============================================
function showNotification(msg) {
    const notif = document.getElementById("notification");
    if (!notif) return;
    notif.textContent = msg;
    notif.style.display = 'block';
    notif.style.opacity = '1';
    clearTimeout(notif._timeout);
    notif._timeout = setTimeout(() => {
        notif.style.opacity = '0';
        setTimeout(() => notif.style.display = 'none', 300);
    }, 3000);
}

// =============================================
// DIENST
// =============================================
function startService() {
    fetch(`https://${GetParentResourceName()}/startService`, {
        method: "POST",
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            type:     document.getElementById('dienst-type')?.value     || '',
            location: document.getElementById('dienst-location')?.value || '',
            notes:    document.getElementById('dienst-notes')?.value    || ''
        })
    });
    const s = document.querySelector('#dienst-status span');
    if (s) { s.textContent = 'Online'; s.className = 'status-online'; }
    showNotification('✅ Dienst wurde gestartet');
}

function endService() {
    fetch(`https://${GetParentResourceName()}/endService`, {
        method: "POST",
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
    });
    const s = document.querySelector('#dienst-status span');
    if (s) { s.textContent = 'Offline'; s.className = 'status-offline'; }
    showNotification('🔴 Dienst wurde beendet');
}

// =============================================
// AKTEN
// =============================================
function GetRecordsByName(name) {
    if (!name) return showNotification('⚠️ Bitte Namen eingeben');
    fetch(`https://${GetParentResourceName()}/getRecords`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name })
    });
}

function AddRecord(name, title, desc, officer) {
    if (!name || !title) return showNotification('⚠️ Name und Titel erforderlich');
    fetch(`https://${GetParentResourceName()}/addRecord`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, title, description: desc, officer })
    });
    showNotification('📁 Akte wurde erstellt');
}

// =============================================
// FAHRZEUGE
// =============================================
function SearchPlate(plate) {
    if (!plate) return showNotification('⚠️ Bitte Kennzeichen eingeben');
    fetch(`https://${GetParentResourceName()}/searchPlate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ plate })
    });
}

function SearchVehiclesByOwner(owner) {
    if (!owner) return showNotification('⚠️ Bitte Besitzer eingeben');
    fetch(`https://${GetParentResourceName()}/searchVehiclesByOwner`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ owner })
    });
}

// =============================================
// WAFFEN
// =============================================
function SearchWeapons(name) {
    if (!name) return showNotification('⚠️ Bitte Namen eingeben');
    fetch(`https://${GetParentResourceName()}/searchWeapons`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ player: name })
    });
}

function RegisterWeapon() {
    const type   = document.getElementById('waffen-type')?.value   || '';
    const serial = document.getElementById('waffen-serial')?.value || '';
    if (!serial) return showNotification('⚠️ Seriennummer erforderlich');
    fetch(`https://${GetParentResourceName()}/registerWeapon`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, serial })
    });
    showNotification('🔫 Waffe wurde registriert');
}

// =============================================
// FAHNDUNG
// =============================================
function AddWanted() {
    const name   = document.getElementById('wanted-name')?.value   || '';
    const reason = document.getElementById('wanted-reason')?.value || '';
    const level  = document.getElementById('wanted-level')?.value  || '';
    if (!name) return showNotification('⚠️ Name erforderlich');
    fetch(`https://${GetParentResourceName()}/addWanted`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, reason, level })
    });
    showNotification('🚨 Fahndung wurde ausgeschrieben');
}

// =============================================
// LEITSTELLE
// =============================================
function sendDispatch(type) {
    fetch(`https://${GetParentResourceName()}/sendDispatch`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type })
    });
    const output = document.getElementById('leitstelle-output');
    if (output) {
        const time = new Date().toLocaleTimeString('de-DE');
        output.innerHTML = `<p>[${time}] 📡 ${type} gesendet</p>` + output.innerHTML;
    }
    showNotification(`📡 ${type} wurde gesendet`);
}

// =============================================
// STRAFENKATALOG
// =============================================
function updateFineTypes() {}

function IssueFine() {
    const player   = document.getElementById('fine-player')?.value   || '';
    const category = document.getElementById('fine-category')?.value || '';
    const type     = document.getElementById('fine-type')?.value     || '';
    const amount   = document.getElementById('fine-amount')?.value   || '';
    const points   = document.getElementById('fine-points')?.value   || '';
    const prison   = document.getElementById('fine-prison')?.value   || '';
    if (!player) return showNotification('⚠️ Spieler angeben');
    fetch(`https://${GetParentResourceName()}/issueFine`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ player, category, type, amount, points, prison })
    });
    showNotification(`💰 Strafe von €${amount} für ${player} verhängt`);
}

// =============================================
// JAILSYSTEM
// =============================================
function sendToJail() {
    const player = document.getElementById('jail-player')?.value || '';
    const time   = document.getElementById('jail-time')?.value   || '';
    const reason = document.getElementById('jail-reason')?.value || '';
    if (!player || !time) return showNotification('⚠️ Spieler und Zeit erforderlich');
    fetch(`https://${GetParentResourceName()}/sendToJail`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ player, time, reason })
    });
    showNotification(`⛓️ ${player} wurde für ${time} Min inhaftiert`);
}

// =============================================
// EINSTELLUNGEN
// =============================================
function toggleSettings() {
    const s = document.getElementById("settings-content");
    if (s) s.style.display = s.style.display === "none" ? "block" : "none";
}