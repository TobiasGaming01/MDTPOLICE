fx_version 'cerulean'
game 'gta5'

author 'Tobi Development'
description 'Police Tablet'
version '1.0.0'
link 'https://github.com/Tobiasgaming01/tobid_police_tablet'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/css/index.css',
     'html/css/background2.png',
    'html/js/index.js',
    'html/img/*'
}
shared_scripts {
'config.lua'
}
 server_scripts {
    'server/main.lua'
 }
 client_scripts {
    'client/main.lua'
 }