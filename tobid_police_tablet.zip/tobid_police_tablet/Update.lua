-- Police Tablet Update Script
-- Version: 1.0.0
-- Author: Cascade AI
-- Description: Update script for police tablet system

local version = "1.0.0"

print("Starting Police Tablet Update...")

-- Check if files exist
local function fileExists(path)
    local file = io.open(path, "r")
    if file then
        file:close()
        return true
    end
    return false
end

-- Update server/main.lua
local function updateServerMain()
    print("Updating server/main.lua...")
    
    local serverMain = [[
-- Police Tablet Server Side
-- Version: ]] .. version .. [[

local QBCore = exports['qb-core']:GetCoreObject()

-- Police Tablet Events
RegisterNetEvent('police-tablet:server:GetPlayerData')
AddEventHandler('police-tablet:server:GetPlayerData', function()
    local source = source
    local Player = QBCore.Functions.GetPlayer(source)
    
    if Player then
        local playerData = {
            name = Player.PlayerData.charinfo.firstname .. ' ' .. Player.PlayerData.charinfo.lastname,
            job = Player.PlayerData.job.label,
            callsign = Player.PlayerData.metadata.callsign or 'NONE'
        }
        
        TriggerClientEvent('police-tablet:client:ReceivePlayerData', source, playerData)
    end
end)

-- Get Records by Name
RegisterNetEvent('police-tablet:server:GetRecordsByName')
AddEventHandler('police-tablet:server:GetRecordsByName', function(name)
    local source = source
    local Player = QBCore.Functions.GetPlayer(source)
    
    if Player then
        local result = MySQL.query.await('SELECT * FROM player_mdt WHERE name = ?', {name})
        TriggerClientEvent('police-tablet:client:ReceiveRecords', source, result)
    end
end)

-- Add Record
RegisterNetEvent('police-tablet:server:AddRecord')
AddEventHandler('police-tablet:server:AddRecord', function(playerName, title, description, officer)
    local source = source
    local Player = QBCore.Functions.GetPlayer(source)
    
    if Player then
        MySQL.insert('INSERT INTO player_mdt (name, title, description, officer, date) VALUES (?, ?, ?, ?, NOW())', {
            playerName, title, description, officer
        })
        
        TriggerClientEvent('QBCore:Notify', source, 'Akte erfolgreich erstellt', 'success')
    end
end)

-- Search Vehicle Plate
RegisterNetEvent('police-tablet:server:SearchPlate')
AddEventHandler('police-tablet:server:SearchPlate', function(plate)
    local source = source
    local Player = QBCore.Functions.GetPlayer(source)
    
    if Player then
        local result = MySQL.query.await('SELECT * FROM player_vehicles WHERE plate = ?', {plate})
        TriggerClientEvent('police-tablet:client:ReceiveVehicleData', source, result)
    end
end)

-- Search Weapons
RegisterNetEvent('police-tablet:server:SearchWeapons')
AddEventHandler('police-tablet:server:SearchWeapons', function(playerName)
    local source = source
    local Player = QBCore.Functions.GetPlayer(source)
    
    if Player then
        local result = MySQL.query.await('SELECT * FROM player_weapons WHERE name = ?', {playerName})
        TriggerClientEvent('police-tablet:client:ReceiveWeaponData', source, result)
    end
end)

-- Add Wanted Person
RegisterNetEvent('police-tablet:server:AddWanted')
AddEventHandler('police-tablet:server:AddWanted', function(name, reason, level)
    local source = source
    local Player = QBCore.Functions.GetPlayer(source)
    
    if Player then
        MySQL.insert('INSERT INTO player_wanted (name, reason, level, date) VALUES (?, ?, ?, NOW())', {
            name, reason, level
        })
        
        TriggerClientEvent('QBCore:Notify', source, 'Fahndung erfolgreich ausgeschrieben', 'success')
    end
end)

-- Issue Fine
RegisterNetEvent('police-tablet:server:IssueFine')
AddEventHandler('police-tablet:server:IssueFine', function(playerName, amount, points, prison, reason)
    local source = source
    local Player = QBCore.Functions.GetPlayer(source)
    
    if Player then
        local targetPlayer = QBCore.Functions.GetPlayerByName(playerName)
        
        if targetPlayer then
            targetPlayer.Functions.RemoveMoney('bank', amount, 'fine')
            TriggerClientEvent('QBCore:Notify', targetPlayer.PlayerData.source, 'Strafe von €' .. amount .. ' erhalten', 'error')
        end
        
        MySQL.insert('INSERT INTO player_fines (name, amount, points, prison, reason, officer, date) VALUES (?, ?, ?, ?, ?, ?, NOW())', {
            playerName, amount, points, prison, reason, Player.PlayerData.charinfo.firstname .. ' ' .. Player.PlayerData.charinfo.lastname
        })
        
        TriggerClientEvent('QBCore:Notify', source, 'Strafe erfolgreich verhängt', 'success')
    end
end)

-- Start Service
RegisterNetEvent('police-tablet:server:StartService')
AddEventHandler('police-tablet:server:StartService', function()
    local source = source
    local Player = QBCore.Functions.GetPlayer(source)
    
    if Player then
        Player.Functions.SetJobDuty(true)
        TriggerClientEvent('QBCore:Notify', source, 'Dienst erfolgreich begonnen', 'success')
        TriggerClientEvent('police-tablet:client:UpdateServiceStatus', source, true)
    end
end)

-- End Service
RegisterNetEvent('police-tablet:server:EndService')
AddEventHandler('police-tablet:server:EndService', function()
    local source = source
    local Player = QBCore.Functions.GetPlayer(source)
    
    if Player then
        Player.Functions.SetJobDuty(false)
        TriggerClientEvent('QBCore:Notify', source, 'Dienst erfolgreich beendet', 'info')
        TriggerClientEvent('police-tablet:client:UpdateServiceStatus', source, false)
    end
end)

print('Police Tablet Server Loaded - Version ' .. version)
]]
    
    local file = io.open("server/main.lua", "w")
    if file then
        file:write(serverMain)
        file:close()
        print("✓ server/main.lua updated successfully")
    else
        print("✗ Failed to update server/main.lua")
    end
end

-- Update client/main.lua
local function updateClientMain()
    print("Updating client/main.lua...")
    
    local clientMain = [[
-- Police Tablet Client Side
-- Version: ]] .. version .. [[

local QBCore = exports['qb-core']:GetCoreObject()
local isOnDuty = false
local tabletOpen = false

-- Register NUI Callback
RegisterNUICallback('closeTablet', function(data, cb)
    SetNuiFocus(false, false)
    tabletOpen = false
    cb('ok')
end)

-- Open Tablet
RegisterKeyMapping('opentablet', 'Open Police Tablet', 'keyboard', 'F2')

RegisterCommand('opentablet', function()
    local Player = QBCore.Functions.GetPlayerData()
    
    if Player.job.name == 'police' then
        if not tabletOpen then
            SetNuiFocus(true, true)
            SendNUIMessage({
                action = 'openTablet',
                playerData = {
                    name = Player.charinfo.firstname .. ' ' .. Player.charinfo.lastname,
                    job = Player.job.label,
                    callsign = Player.metadata.callsign or 'NONE'
                }
            })
            tabletOpen = true
        else
            SetNuiFocus(false, false)
            SendNUIMessage({
                action = 'closeTablet'
            })
            tabletOpen = false
        end
    else
        QBCore:Notify('Du bist kein Polizist!', 'error')
    end
end)

-- Service Status Update
RegisterNetEvent('police-tablet:client:UpdateServiceStatus')
AddEventHandler('police-tablet:client:UpdateServiceStatus', function(status)
    isOnDuty = status
    SendNUIMessage({
        action = 'updateServiceStatus',
        status = status
    })
end)

-- Receive Player Data
RegisterNetEvent('police-tablet:client:ReceivePlayerData')
AddEventHandler('police-tablet:client:ReceivePlayerData', function(data)
    SendNUIMessage({
        action = 'updatePlayerData',
        data = data
    })
end)

-- Receive Records
RegisterNetEvent('police-tablet:client:ReceiveRecords')
AddEventHandler('police-tablet:client:ReceiveRecords', function(records)
    SendNUIMessage({
        action = 'updateRecords',
        records = records
    })
end)

-- Receive Vehicle Data
RegisterNetEvent('police-tablet:client:ReceiveVehicleData')
AddEventHandler('police-tablet:client:ReceiveVehicleData', function(vehicles)
    SendNUIMessage({
        action = 'updateVehicleData',
        vehicles = vehicles
    })
end)

-- Receive Weapon Data
RegisterNetEvent('police-tablet:client:ReceiveWeaponData')
AddEventHandler('police-tablet:client:ReceiveWeaponData', function(weapons)
    SendNUIMessage({
        action = 'updateWeaponData',
        weapons = weapons
    })
end)

-- Export Functions for NUI
exports('GetRecordsByName', function(name)
    TriggerServerEvent('police-tablet:server:GetRecordsByName', name)
end)

exports('AddRecord', function(playerName, title, description, officer)
    TriggerServerEvent('police-tablet:server:AddRecord', playerName, title, description, officer)
end)

exports('SearchPlate', function(plate)
    TriggerServerEvent('police-tablet:server:SearchPlate', plate)
end)

exports('SearchWeapons', function(playerName)
    TriggerServerEvent('police-tablet:server:SearchWeapons', playerName)
end)

exports('AddWanted', function()
    local name = document.getElementById('wanted-name').value
    local reason = document.getElementById('wanted-reason').value
    local level = document.getElementById('wanted-level').value
    
    TriggerServerEvent('police-tablet:server:AddWanted', name, reason, level)
end)

exports('IssueFine', function()
    local playerName = document.getElementById('fine-player').value
    local amount = document.getElementById('fine-amount').value
    local points = document.getElementById('fine-points').value
    local prison = document.getElementById('fine-prison').value
    
    TriggerServerEvent('police-tablet:server:IssueFine', playerName, amount, points, prison, 'Straftat')
end)

exports('startService', function()
    TriggerServerEvent('police-tablet:server:StartService')
end)

exports('endService', function()
    TriggerServerEvent('police-tablet:server:EndService')
end)

print('Police Tablet Client Loaded - Version ' .. version)
]]
    
    local file = io.open("client/main.lua", "w")
    if file then
        file:write(clientMain)
        file:close()
        print("✓ client/main.lua updated successfully")
    else
        print("✗ Failed to update client/main.lua")
    end
end

-- Update config.lua
local function updateConfig()
    print("Updating config.lua...")
    
    local config = [[
-- Police Tablet Configuration
-- Version: ]] .. version .. [[

Config = {}

-- Tablet Settings
Config.TabletKey = 'F2' -- Key to open tablet
Config.RequireDuty = true -- Require officer to be on duty to use tablet
Config.Animations = true -- Enable tablet animations

-- Database Settings
Config.Database = {
    MDTTable = 'player_mdt',
    VehicleTable = 'player_vehicles',
    WeaponTable = 'player_weapons',
    WantedTable = 'player_wanted',
    FinesTable = 'player_fines'
}

-- UI Settings
Config.UI = {
    Theme = 'dark', -- dark or light
    AutoSave = true, -- Auto-save form data
    Notifications = true -- Enable notifications
}

-- Permissions
Config.Permissions = {
    ['police'] = true,
    ['ambulance'] = false,
    ['mechanic'] = false
}

-- Fines Configuration
Config.Fines = {
    Speeding = {
        {level = 10, amount = 30, points = 1},
        {level = 20, amount = 60, points = 2},
        {level = 30, amount = 100, points = 2},
        {level = 40, amount = 160, points = 3},
        {level = 50, amount = 240, points = 3},
        {level = 60, amount = 400, points = 3},
        {level = 70, amount = 600, points = 3, prison = 1},
        {level = 80, amount = 800, points = 3, prison = 2},
        {level = 100, amount = 1200, points = 3, prison = 3}
    },
    RedLight = {
        {duration = 1, amount = 90, points = 1},
        {duration = 3, amount = 200, points = 2},
        {duration = 5, amount = 360, points = 3}
    },
    Parking = {
        {type = 'short', amount = 15},
        {type = 'long', amount = 25},
        {type = 'disabled', amount = 35},
        {type = 'firelane', amount = 55, points = 1},
        {type = 'handicap', amount = 70, points = 1}
    }
}

print('Police Tablet Config Loaded - Version ' .. version)
]]
    
    local file = io.open("config.lua", "w")
    if file then
        file:write(config)
        file:close()
        print("✓ config.lua updated successfully")
    else
        print("✗ Failed to update config.lua")
    end
end

-- Run updates
updateServerMain()
updateClientMain()
updateConfig()

print("Police Tablet Update Complete! Version: " .. version)
print("Please restart the server to apply changes.")