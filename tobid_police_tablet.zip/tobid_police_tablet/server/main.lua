-- Database Connection
local MySQL = exports.oxmysql

-- Police Tablet Server Side
-- Version: 1.0.0

-- Framework Detection
local QBCore = nil
local ESX = nil

if Config.FrameWork == "qb" then
    QBCore = exports['qb-core']:GetCoreObject()
elseif Config.FrameWork == "esx" then
    ESX = exports["es_extended"]:getSharedObject()
end

-- Framework Helper Functions
local function GetPlayer(source)
    if Config.FrameWork == "qb" and QBCore and QBCore.Functions then
        return QBCore.Functions.GetPlayer(source)
    elseif Config.FrameWork == "esx" and ESX then
        return ESX.GetPlayerFromId(source)
    end
    return nil
end

local function GetPlayerByName(name)
    if Config.FrameWork == "qb" and QBCore and QBCore.Functions then
        return QBCore.Functions.GetPlayerByName(name)
    elseif Config.FrameWork == "esx" and ESX then
        local xPlayers = ESX.GetPlayers()
        for _, playerId in ipairs(xPlayers) do
            local xPlayer = ESX.GetPlayerFromId(playerId)
            if xPlayer and xPlayer.getName() == name then
                return xPlayer
            end
        end
    end
    return nil
end

local function GetPlayerName(playerOrId)
    if Config.FrameWork == "qb" then
        if type(playerOrId) == "number" then
            -- If it's an ID, get the player first
            local player = QBCore.Functions.GetPlayer(playerOrId)
            return player and (player.PlayerData.charinfo.firstname .. ' ' .. player.PlayerData.charinfo.lastname) or 'Unknown'
        else
            -- If it's already a player object
            return playerOrId.PlayerData.charinfo.firstname .. ' ' .. playerOrId.PlayerData.charinfo.lastname
        end
    elseif Config.FrameWork == "esx" then
        if type(playerOrId) == "number" then
            -- If it's an ID, get the player first
            local xPlayer = ESX.GetPlayerFromId(playerOrId)
            return xPlayer and (xPlayer.getName() or xPlayer.getFullName() or 'Unknown') or 'Unknown'
        else
            -- If it's already a player object
            return playerOrId.getName() or playerOrId.getFullName() or 'Unknown'
        end
    end
    return 'Unknown'
end

local function GetPlayerJob(player)
    if Config.FrameWork == "qb" then
        return player.PlayerData.job.label
    elseif Config.FrameWork == "esx" then
        return player.job.label
    end
    return 'Unknown'
end

local function RemoveMoney(player, amount, reason)
    if Config.FrameWork == "qb" then
        player.Functions.RemoveMoney('bank', amount, reason)
    elseif Config.FrameWork == "esx" then
        player.removeAccountMoney('bank', amount)
    end
end

local function SetDuty(player, state)
    if Config.FrameWork == "qb" then
        player.Functions.SetJobDuty(state)
    elseif Config.FrameWork == "esx" then
        -- ESX duty handling would go here if needed
    end
end

local function NotifyPlayer(source, message, type)
    if Config.FrameWork == "qb" then
        TriggerClientEvent('QBCore:Notify', source, message, type)
    elseif Config.FrameWork == "esx" then
        TriggerClientEvent('esx:showNotification', source, message, type)
    end
end

local Officers = {}
local JailPlayers = {}

-- Police Tablet Events
RegisterNetEvent('police-tablet:server:GetPlayerData')
AddEventHandler('police-tablet:server:GetPlayerData', function()
    local source = source
    local Player = GetPlayer(source)
    
    if Player then
        local playerData = {
            name = GetPlayerName(Player),
            job = GetPlayerJob(Player),
            callsign = (Config.FrameWork == "qb" and Player.PlayerData.metadata.callsign) or 'NONE'
        }
        
        TriggerClientEvent('police-tablet:client:ReceivePlayerData', source, playerData)
    end
end)

-- Get Records by Name
RegisterNetEvent('police-tablet:server:GetRecordsByName')
AddEventHandler('police-tablet:server:GetRecordsByName', function(name)
    local source = source
    local Player = GetPlayer(source)
    
    if Player then
        local result = MySQL.Sync.fetchAll('SELECT * FROM player_mdt WHERE name = ?', {name})
        TriggerClientEvent('police-tablet:client:ReceiveRecords', source, result)
    end
end)

-- Add Record
RegisterNetEvent('police-tablet:server:AddRecord')
AddEventHandler('police-tablet:server:AddRecord', function(playerName, title, description, officer)
    local source = source
    local Player = GetPlayer(source)
    
    if Player then
        MySQL.Sync.execute('INSERT INTO player_mdt (name, title, description, officer, date) VALUES (?, ?, ?, ?, NOW())', {
            playerName, title, description, officer
        })
        
        NotifyPlayer(source, 'Akte erfolgreich erstellt', 'success')
    end
end)

-- Search Vehicle Plate
RegisterNetEvent('police-tablet:server:SearchPlate')
AddEventHandler('police-tablet:server:SearchPlate', function(plate)
    local source = source
    local Player = GetPlayer(source)
    
    if Player then
        local result = MySQL.Sync.fetchAll('SELECT * FROM player_vehicles WHERE plate = ?', {plate})
        TriggerClientEvent('police-tablet:client:ReceiveVehicleData', source, result)
    end
end)

-- Search Weapons
RegisterNetEvent('police-tablet:server:SearchWeapons')
AddEventHandler('police-tablet:server:SearchWeapons', function(playerName)
    local source = source
    local Player = GetPlayer(source)
    
    if Player then
        local result = MySQL.Sync.fetchAll('SELECT * FROM player_weapons WHERE name = ?', {playerName})
        TriggerClientEvent('police-tablet:client:ReceiveWeaponData', source, result)
    end
end)

-- Add Wanted Person
RegisterNetEvent('police-tablet:server:AddWanted')
AddEventHandler('police-tablet:server:AddWanted', function(name, reason, level)
    local source = source
    local Player = GetPlayer(source)
    
    if Player then
        MySQL.Sync.execute('INSERT INTO player_wanted (name, reason, level, date) VALUES (?, ?, ?, NOW())', {
            name, reason, level
        })
        
        NotifyPlayer(source, 'Fahndung erfolgreich ausgeschrieben', 'success')
    end
end)

-- Issue Fine
RegisterNetEvent('police-tablet:server:IssueFine')
AddEventHandler('police-tablet:server:IssueFine', function(playerName, amount, points, prison, reason)
    local source = source
    local Player = GetPlayer(source)
    
    if Player then
        local targetPlayer = GetPlayerByName(playerName)
        
        if targetPlayer then
            RemoveMoney(targetPlayer, amount, 'fine')
            NotifyPlayer(targetPlayer.source or targetPlayer.PlayerData.source, 'Strafe von €' .. amount .. ' erhalten', 'error')
        end
        
        MySQL.Sync.execute('INSERT INTO player_fines (name, amount, points, prison, reason, officer, date) VALUES (?, ?, ?, ?, ?, ?, NOW())', {
            playerName, amount, points, prison, reason, GetPlayerName(Player)
        })
        
        NotifyPlayer(source, 'Strafe erfolgreich verhängt', 'success')
    end
end)

-- Start Service
RegisterNetEvent('police-tablet:server:StartService')
AddEventHandler('police-tablet:server:StartService', function()
    local source = source
    local Player = GetPlayer(source)
    
    if Player then
        SetDuty(Player, true)
        NotifyPlayer(source, 'Dienst erfolgreich begonnen', 'success')
        TriggerClientEvent('police-tablet:client:UpdateServiceStatus', source, true)
        Officers[source] = true
    end
end)

-- End Service
RegisterNetEvent('police-tablet:server:EndService')
AddEventHandler('police-tablet:server:EndService', function()
    local source = source
    local Player = GetPlayer(source)
    
    if Player then
        SetDuty(Player, false)
        NotifyPlayer(source, 'Dienst erfolgreich beendet', 'info')
        TriggerClientEvent('police-tablet:client:UpdateServiceStatus', source, false)
        Officers[source] = nil
    end
end)

-- Legacy Events for Compatibility
RegisterNetEvent("tablet:updateDuty")
AddEventHandler("tablet:updateDuty", function (state)
    local src = source
    if state then 
        Officers[src] = true 
    else
        Officers[src] = nil
    end
end)

RegisterNetEvent("tablet:jailPlayer")
AddEventHandler("tablet:jailPlayer", function (targetId, time)
    if Config.UseJail then
        print(string.format("Spieler %s wurde für %s Minuten eingesperrt.", targetId, time))
    end    
end)

RegisterNetEvent("tablet:createDispatch")
AddEventHandler("tablet:createDispatch", function(message, coords)
    if Config.UseDispatch then
        for officer, _ in pairs(Officers) do
            TriggerClientEvent("tablet:dispatchAlert", officer, {
                message = message,
                coords = coords
            })
        end
    end
end)

RegisterNetEvent("tablet:SendDispatch")
AddEventHandler("tablet:SendDispatch", function (data)
    if Config.UseDispatch then
        TriggerClientEvent("tablet:SendDispatch", -1, data)
    end
end)

RegisterNetEvent("tablet:getOfficers")
AddEventHandler("tablet:getOfficers", function()
    local players = GetPlayers()
    local officers = {}

    for _, id in pairs(players) do
        table.insert(officers, {
            id = id,
            name = GetPlayerName(id)
        })
    end

    TriggerClientEvent("tablet:sendOfficers", source, officers)
end)

local function GetPlayerIDByName(firstname, lastname)
    local result = MySQL.Sync.fetchAll("SELECT id FROM players WHERE firstname = ? AND lastname = ?", {firstname, lastname})
    if result[1] then
        return result[1].id
    else
        return nil
    end
end

RegisterNetEvent("tablet:getWeaponsByName")
AddEventHandler("tablet:getWeaponsByName", function(firstname, lastname)
    local src = source
    local playerID = GetPlayerIDByName(firstname, lastname)
    if not playerID then
        TriggerClientEvent("tablet:returnWeaponsByName", src, nil)
        return
    end

    local weapons = MySQL.Sync.fetchAll("SELECT name, license FROM weapons WHERE player_id = ?", {playerID})
    TriggerClientEvent("tablet:returnWeaponsByName", src, { name = firstname.." "..lastname, weapons = weapons })
end)

RegisterNetEvent("tablet:getVehicleByPlate")
AddEventHandler("tablet:getVehicleByPlate", function(plate)
    local src = source
    local vehicle = MySQL.Sync.fetchAll([[
        SELECT v.plate, v.model, v.status, p.firstname, p.lastname
        FROM vehicles v
        JOIN players p ON v.owner_id = p.id
        WHERE v.plate = ?
    ]], {plate})

    if vehicle[1] then
        TriggerClientEvent("tablet:returnVehicleInfo", src, {
            plate = vehicle[1].plate,
            model = vehicle[1].model,
            status = vehicle[1].status,
            owner = vehicle[1].firstname.." "..vehicle[1].lastname
        })
    else
        TriggerClientEvent("tablet:returnVehicleInfo", src, nil)
    end
end)

RegisterNetEvent("tablet:getRecords")
AddEventHandler("tablet:getRecords", function(firstname, lastname)
    local src = source
    local result = MySQL.Sync.fetchAll("SELECT id FROM players WHERE firstname = ? AND lastname = ?", {firstname, lastname})

    if not result[1] then
        TriggerClientEvent("tablet:returnRecords", src, nil)
        return
    end

    local playerID = result[1].id
    local records = MySQL.Sync.fetchAll("SELECT * FROM records WHERE player_id = ?", {playerID})
    TriggerClientEvent("tablet:returnRecords", src, records)
end)

RegisterNetEvent("tablet:addRecord")
AddEventHandler("tablet:addRecord", function(firstname, lastname, title, description, officer)
    local src = source
    local result = MySQL.Sync.fetchAll("SELECT id FROM players WHERE firstname = ? AND lastname = ?", {firstname, lastname})

    if not result[1] then return end
    local playerID = result[1].id

    MySQL.Sync.execute("INSERT INTO records (player_id, title, description, officer) VALUES (?, ?, ?, ?)", 
        {playerID, title, description, officer})

    TriggerClientEvent("tablet:returnRecords", src, MySQL.Sync.fetchAll("SELECT * FROM records WHERE player_id = ?", {playerID}))
end)

print('Police Tablet Server Loaded - Version 1.0.0')