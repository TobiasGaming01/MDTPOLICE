-- Police Tablet Configuration
-- Version: 1.0.0

Config = {}

-- Framework Settings
Config.FrameWork = "esx" -- "esx", "qb", "standalone"

-- Tablet Settings
Config.TabletKey = 'F2' -- Key to open tablet
Config.tabletOpenKey = "F3" -- Set to key name (e.g., "F2") or "" to disable F2 opening
Config.RequireDuty = true -- Require officer to be on duty to use tablet
Config.Animations = true -- Enable tablet animations

-- Database Settings
Config.Database = {
    MDTTable = 'player_mdt',
    VehicleTable = 'player_vehicles',
    WeaponTable = 'player_weapons',
    WantedTable = 'player_wanted',
    FinesTable = 'player_fines'
}

-- UI Settings
Config.UI = {
    Theme = 'dark', -- dark or light
    AutoSave = true, -- Auto-save form data
    Notifications = true -- Enable notifications
}

-- System Settings
Config.UseDispatch = true
Config.Phone = "lb-phone" -- da bekommen über das Dispatch 
Config.UseJail = true
Config.PoliceJob = "police"
Config.OpenCommand = "tablet"
Config.webhook = "https://discordwebhoor/"

-- Sprache wählen
Config.Theme = "de" -- en oder de
Config.Panik = "20" -- https://docs.fivem.net/docs/game-references/controls/

-- Localization
Config.Locale = {
    ["de"] = {
        tablet_title = "Polizei Tablet",
        players = "Spieler",
        dispatch = "Dispatch",
        officers = "Kollegen",
        search_player = "Spieler suchen",
        jail_player = "Spieler einsperren",
        fine_player = "Strafe geben",
        close = "Schließen",
        duty_on = "Dienst starten",
        duty_off = "Dienst beenden",
        panik = "Panik Button ein von den Kollegen hat gedrückt",
    },

    ["en"] = {
        tablet_title = "Police Tablet",
        players = "Players",
        dispatch = "Dispatch",
        officers = "Officers",
        search_player = "Search Player",
        jail_player = "Jail Player",
        fine_player = "Give Fine",
        close = "Close",
        duty_on = "Start Duty",
        duty_off = "End Duty",
        panik = "One of the colleagues pressed the panic button.",
    }
}

-- Permissions
Config.Permissions = {
    ['police'] = true,
    ['ambulance'] = false,
    ['mechanic'] = false
}

-- Fines Configuration
Config.Fines = {
    Speeding = {
        {level = 10, amount = 30, points = 1},
        {level = 20, amount = 60, points = 2},
        {level = 30, amount = 100, points = 2},
        {level = 40, amount = 160, points = 3},
        {level = 50, amount = 240, points = 3},
        {level = 60, amount = 400, points = 3},
        {level = 70, amount = 600, points = 3, prison = 1},
        {level = 80, amount = 800, points = 3, prison = 2},
        {level = 100, amount = 1200, points = 3, prison = 3}
    },
    RedLight = {
        {duration = 1, amount = 90, points = 1},
        {duration = 3, amount = 200, points = 2},
        {duration = 5, amount = 360, points = 3}
    },
    Parking = {
        {type = 'short', amount = 15},
        {type = 'long', amount = 25},
        {type = 'disabled', amount = 35},
        {type = 'firelane', amount = 55, points = 1},
        {type = 'handicap', amount = 70, points = 1}
    }
}

-- Jail Settings
Config.JailCoords = vector3(1690.0, 2593.0, 45.5) -- Default jail coordinates

print('Police Tablet Config Loaded - Version 1.0.0')