-- Police Tablet Database Schema
-- Version: 1.0.0
-- Compatible with QBCore Framework

-- QBCore Players Table (Enhanced for QBCore)
CREATE TABLE IF NOT EXISTS `players` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `citizenid` VARCHAR(50) UNIQUE,
    `steam` VARCHAR(50),
    `license` VARCHAR(50),
    `name` VARCHAR(255),
    `firstname` VARCHAR(50),
    `lastname` VARCHAR(50),
    `birthdate` VARCHAR(10),
    `gender` VARCHAR(10),
    `nationality` VARCHAR(50),
    `phone_number` VARCHAR(20),
    `accounts` LONGTEXT,
    `job` LONGTEXT,
    `gang` LONGTEXT,
    `position` LONGTEXT,
    `metadata` LONGTEXT,
    `inventory` LONGTEXT,
    `tattoos` LONGTEXT,
    `skin` LONGTEXT,
    `status` LONGTEXT,
    `isdead` TINYINT(1) DEFAULT 0,
    `lastproperty` VARCHAR(255),
    `craftingrep` TINYINT(1) DEFAULT 0,
    `apartment` LONGTEXT,
    `houseid` VARCHAR(255),
    `depcount` INT(11) DEFAULT 0,
    `jobrep` TINYINT(1) DEFAULT 0,
    `gangrep` TINYINT(1) DEFAULT 0,
    `storageid` INT(11) DEFAULT 0,
    `fingerprint` VARCHAR(255),
    `walletid` VARCHAR(255),
    `phonedata` LONGTEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `last_seen` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `citizenid` (`citizenid`),
    INDEX `steam` (`steam`),
    INDEX `license` (`license`)
);

-- QBCore Player MDT Records
CREATE TABLE IF NOT EXISTS `qb_mdt_records` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `citizenid` VARCHAR(50) NOT NULL,
    `name` VARCHAR(100) NOT NULL,
    `title` VARCHAR(100) NOT NULL,
    `description` TEXT NOT NULL,
    `officer` VARCHAR(100) NOT NULL,
    `date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `citizenid` (`citizenid`),
    INDEX `name` (`name`),
    INDEX `officer` (`officer`)
);

-- QBCore Player Vehicles
CREATE TABLE IF NOT EXISTS `player_vehicles` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `license` VARCHAR(50) NOT NULL,
    `citizenid` VARCHAR(50) NOT NULL,
    `vehicle` VARCHAR(100) NOT NULL,
    `hash` VARCHAR(50),
    `modifications` LONGTEXT,
    `plate` VARCHAR(12) NOT NULL,
    `fakeplate` VARCHAR(12),
    `garage` VARCHAR(50) DEFAULT 'pillboxgarage',
    `fuel` INT(11) DEFAULT 100,
    `engine` FLOAT DEFAULT 100,
    `body` FLOAT DEFAULT 100,
    `state` INT(11) DEFAULT 1,
    `depotprice` INT(11) DEFAULT 0,
    `drivingdistance` INT(11) DEFAULT 0,
    `status` ENUM('normal','gestohlen','impounded') DEFAULT 'normal',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `plate` (`plate`),
    INDEX `citizenid` (`citizenid`),
    INDEX `license` (`license`)
);

-- QBCore Player Weapons
CREATE TABLE IF NOT EXISTS `player_weapons` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `identifier` VARCHAR(50) NOT NULL,
    `citizenid` VARCHAR(50) NOT NULL,
    `name` VARCHAR(100) NOT NULL,
    `weapon` VARCHAR(100) NOT NULL,
    `ammo` INT(11) DEFAULT 0,
    `license` TINYINT(1) DEFAULT 0,
    `components` LONGTEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `identifier` (`identifier`),
    INDEX `citizenid` (`citizenid`)
);

-- QBCore Player Wanted List
CREATE TABLE IF NOT EXISTS `qb_wanted` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `citizenid` VARCHAR(50) NOT NULL,
    `name` VARCHAR(100) NOT NULL,
    `reason` TEXT NOT NULL,
    `level` INT(11) DEFAULT 1,
    `officer` VARCHAR(100),
    `date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `active` TINYINT(1) DEFAULT 1,
    PRIMARY KEY (`id`),
    INDEX `citizenid` (`citizenid`),
    INDEX `name` (`name`),
    INDEX `active` (`active`)
);

-- QBCore Player Fines
CREATE TABLE IF NOT EXISTS `qb_fines` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `citizenid` VARCHAR(50) NOT NULL,
    `name` VARCHAR(100) NOT NULL,
    `amount` INT(11) NOT NULL,
    `points` INT(11) DEFAULT 0,
    `prison` INT(11) DEFAULT 0,
    `reason` TEXT NOT NULL,
    `officer` VARCHAR(100) NOT NULL,
    `date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `paid` TINYINT(1) DEFAULT 0,
    PRIMARY KEY (`id`),
    INDEX `citizenid` (`citizenid`),
    INDEX `name` (`name`),
    INDEX `officer` (`officer`)
);

-- QBCore Legacy Records Table (For Compatibility)
CREATE TABLE IF NOT EXISTS `records` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `citizenid` VARCHAR(50),
    `title` VARCHAR(100),       
    `description` TEXT,         
    `officer` VARCHAR(100),     
    `date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `citizenid` (`citizenid`)
);

-- Insert default data if needed
INSERT IGNORE INTO `qb_mdt_records` (`citizenid`, `name`, `title`, `description`, `officer`) VALUES 
('system', 'System', 'Willkommen', 'QBCore Polizeitablet System wurde erfolgreich installiert.', 'Admin');

-- Notes:
-- This SQL file creates all necessary tables for the Police Tablet system
-- Compatible with QBCore Framework
-- Uses QBCore standard table names and citizenid
-- All tables use IF NOT EXISTS to prevent errors during installation
