# Police Tablet - Lizenzen

## Deutsch

### Lizenzbedingungen
Dieses FiveM-Script (Police Tablet) wird unter den folgenden Bedingungen bereitgestellt:

- **Nutzung**: Kostenlos für private und kommerzielle FiveM-Server
- **Modifikation**: Erlaubt, aber der ursprüngliche Autor muss im Code erwähnt bleiben
- **Weitergabe**: Erlaubt, aber nicht als eigenständiges Produkt zu verkaufen
- **Haftung**: Keine Haftung für Schäden oder Datenverlust

### Anforderungen
- FiveM Server
- ESX Legacy oder QBCore Framework
- MySQL Datenbank

### Installation
1. Alle Dateien in den `resources/tobid_police_tablet` Ordner kopieren
2. `ensure tobid_police_tablet` in server.cfg hinzufügen
3. Datenbank-Tabellen erstellen (siehe SQL-Dateien)
4. Config.lua anpassen

### Support
Für Support und Updates besuchen Sie unseren Discord Server.

---

# Police Tablet - Licenses

## English

### License Terms
This FiveM script (Police Tablet) is provided under the following terms:

- **Usage**: Free for private and commercial FiveM servers
- **Modification**: Allowed, but original author must remain credited in the code
- **Distribution**: Allowed, but not as a standalone product for sale
- **Liability**: No liability for damages or data loss

### Requirements
- FiveM Server
- ESX Legacy or QBCore Framework
- MySQL Database

### Installation
1. Copy all files to `resources/tobid_police_tablet` folder
2. Add `ensure tobid_police_tablet` to server.cfg
3. Create database tables (see SQL files)
4. Configure config.lua

### Support
For support and updates, please visit our Discord server.
