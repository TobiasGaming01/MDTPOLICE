-- Police Tablet Database Schema
-- Version: 1.0.0
-- Compatible with ESX Framework

-- ESX Players Table (Standard ESX Structure)
CREATE TABLE IF NOT EXISTS `users` (
    `identifier` VARCHAR(50) NOT NULL,
    `accounts` LONGTEXT DEFAULT NULL,
    `group` VARCHAR(50) DEFAULT 'user',
    `inventory` LONGTEXT DEFAULT NULL,
    `job` VARCHAR(20) DEFAULT 'unemployed',
    `job_grade` INT DEFAULT 0,
    `loadout` LONGTEXT DEFAULT NULL,
    `position` VARCHAR(255) DEFAULT '{"x":-269.4,"y":-955.3,"z":31.2,"heading":205.8}',
    `firstname` VARCHAR(16) DEFAULT NULL,
    `lastname` VARCHAR(16) DEFAULT NULL,
    `dateofbirth` VARCHAR(10) DEFAULT NULL,
    `sex` VARCHAR(1) DEFAULT NULL,
    `height` INT DEFAULT NULL,
    `skin` LONGTEXT DEFAULT NULL,
    `status` LONGTEXT DEFAULT NULL,
    `is_dead` BOOLEAN DEFAULT FALSE,
    `id` INT AUTO_INCREMENT,
    `disabled` BOOLEAN DEFAULT FALSE,
    `last_property` VARCHAR(255) DEFAULT NULL,
    `last_weapon` VARCHAR(255) DEFAULT NULL,
    `last_car` VARCHAR(255) DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `last_seen` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `identifier` (`identifier`)
);

-- ESX Player MDT Records
CREATE TABLE IF NOT EXISTS `esx_mdt_records` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `identifier` VARCHAR(50) NOT NULL,
    `name` VARCHAR(100) NOT NULL,
    `title` VARCHAR(100) NOT NULL,
    `description` TEXT NOT NULL,
    `officer` VARCHAR(100) NOT NULL,
    `date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `identifier` (`identifier`),
    INDEX `name` (`name`),
    INDEX `officer` (`officer`)
);

-- ESX Player Vehicles
CREATE TABLE IF NOT EXISTS `owned_vehicles` (
    `owner` VARCHAR(60) NOT NULL,
    `plate` VARCHAR(12) NOT NULL,
    `vehicle` VARCHAR(255) NOT NULL,
    `type` VARCHAR(255) NOT NULL,
    `job` VARCHAR(255) DEFAULT NULL,
    `stored` TINYINT(1) DEFAULT NULL,
    `parking` VARCHAR(255) DEFAULT NULL,
    `pound` VARCHAR(255) DEFAULT NULL,
    `fuel` INT(11) DEFAULT 100,
    `engine` FLOAT DEFAULT 100,
    `body` FLOAT DEFAULT 100,
    `condition` INT(11) DEFAULT 100,
    `color1` INT DEFAULT 0,
    `color2` INT DEFAULT 0,
    `modifications` LONGTEXT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`plate`),
    INDEX `owner` (`owner`)
);

-- ESX Player Weapons
CREATE TABLE IF NOT EXISTS `user_weapons` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `identifier` VARCHAR(50) NOT NULL,
    `weaponName` VARCHAR(100) NOT NULL,
    `ammo` INT DEFAULT 0,
    `components` LONGTEXT DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `identifier` (`identifier`)
);

-- ESX Player Wanted List
CREATE TABLE IF NOT EXISTS `esx_wanted` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `identifier` VARCHAR(50) NOT NULL,
    `name` VARCHAR(100) NOT NULL,
    `reason` TEXT NOT NULL,
    `level` INT(11) DEFAULT 1,
    `officer` VARCHAR(100),
    `date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `active` TINYINT(1) DEFAULT 1,
    PRIMARY KEY (`id`),
    INDEX `identifier` (`identifier`),
    INDEX `name` (`name`),
    INDEX `active` (`active`)
);

-- ESX Player Fines
CREATE TABLE IF NOT EXISTS `esx_fines` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `identifier` VARCHAR(50) NOT NULL,
    `name` VARCHAR(100) NOT NULL,
    `amount` INT(11) NOT NULL,
    `points` INT(11) DEFAULT 0,
    `prison` INT(11) DEFAULT 0,
    `reason` TEXT NOT NULL,
    `officer` VARCHAR(100) NOT NULL,
    `date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `paid` TINYINT(1) DEFAULT 0,
    PRIMARY KEY (`id`),
    INDEX `identifier` (`identifier`),
    INDEX `name` (`name`),
    INDEX `officer` (`officer`)
);

-- ESX Legacy Records Table (For Compatibility)
CREATE TABLE IF NOT EXISTS `records` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `identifier` VARCHAR(50),
    `title` VARCHAR(100),       
    `description` TEXT,         
    `officer` VARCHAR(100),     
    `date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `identifier` (`identifier`)
);

-- Insert default data if needed
INSERT IGNORE INTO `esx_mdt_records` (`identifier`, `name`, `title`, `description`, `officer`) VALUES 
('system', 'System', 'Willkommen', 'ESX Polizeitablet System wurde erfolgreich installiert.', 'Admin');

-- Notes:
-- This SQL file creates all necessary tables for the Police Tablet system
-- Compatible with ESX Framework
-- Uses ESX standard table names (users, owned_vehicles, user_weapons)
-- All tables use IF NOT EXISTS to prevent errors during installation
